package ar.com.centro8.java.curso;

public class Auto {
    //una clase es una plantilla o molde en donde se definen los atributos y métodos
    //que tendrán los objetos.

    //atributos
    //definimos los atributos o propiedades (son variables que indican las características)
    String marca;
    String modelo;
    String color;
    int velocidad;

    //Constructores
    //si no definimos un método constructor, se crea uno vacío por defecto.
    //los métodos constructores tienen el mismo nombre de la clase y llevan paréntesis

    //constructor vacío
    /**
     * Método deprecado por Francisco Acuña
     * por considerarse obsoleto y poco seguro.
     */
    @Deprecated
    Auto(){};

    //sobrecarga de constructores
    //constuctor completo
    Auto(String marca, String modelo, String color, int velocidad){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = velocidad;
    }
    //cuando creamos un constructor con parámetros debemos declarar el constructor vacío 
    //si lo queremos utilizar, ya no se crea por defecto.

    //más sobrecarga
    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    /**
     * Constructor para los autos de marca Ford
     * @param modelo
     * @param color
     */
    public Auto(String modelo, String color) {
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    
    //métodos
    //definimos los métodos, son bloques de código que definen el comportamiento del objeto
    //son las acciones.
    void acelerar(){
        velocidad += 10;
    }
    //esto es un procedimiento, no devuelve valor. Cuando los métodos no retornan valor
    //deben llevar la palabra reservada void en su encabezado



    void frenar(){
        velocidad -= 10;
    }


    //sobrecarga de métodos
    void acelerar(int kilometros){
        velocidad += kilometros;
    }

    /**
     * Si el turbo es true, se incrementa el doble de kilómetros a la velocidad
     * @param kilometros = son los kilómetros que se van a incrementar
     * @param turbo = true si tiene turbo
     */
    void acelerar(int kilometros, boolean turbo){
        if(turbo) velocidad += kilometros*2;
        else velocidad += kilometros;
    }

    void frenar(int kilometros){
        // velocidad -= kilometros;
        if(velocidad-kilometros<0) velocidad=0;
        else velocidad -= kilometros;
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    int obtenerVelocidad(){
        return velocidad;
    }

    @Override //la anotación de Override no es obligatoria, pero es una buena práctica
    public String toString(){
        return "El auto es un " + marca + ", modelo " + modelo +
                            ", de color " + color + ". Y tiene una velocidad de " + 
                            velocidad + "kms. x hora.";
    }

}
