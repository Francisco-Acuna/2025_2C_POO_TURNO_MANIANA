package ar.com.centro8.java.curso;

public class TestClass {
    public static void main(String[] args) {
        System.out.println("** Test de la clase Auto **");

        //construimos un objeto de la clase Auto
        Auto auto1 = new Auto();
        //un objeto es una instancia de una clase, es decir, una entidad con
        //características (atributos) y comportamiento (métodos)

        //damos estado al objeto (completar el valor de sus atributos)
        auto1.marca = "Fiat";
        auto1.modelo = "Fiorino";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        //imprimimos los valores de los atributos
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

        //utilizamos los métodos de la clase Auto
        auto1.acelerar();
        System.out.println(auto1.velocidad);

        auto1.acelerar();
        auto1.acelerar();
        auto1.acelerar();
        System.out.println(auto1.velocidad);

        //creamos otro objeto de la clase Auto
        Auto auto2 = new Auto();

        //damos estado al auto2
        auto2.marca = "Fiat";
        auto2.modelo = "Cronos";
        auto2.color = "Azul";
        auto2.velocidad = 0;

        System.out.println("El auto es un " + auto2.marca + ", modelo " + auto2.modelo +
                            ", de color " + auto2.color + ". Y tiene una velocidad de " + 
                            auto2.velocidad + "kms. x hora.");

        for (int i=0; i<5; i++) auto2.acelerar();
        auto2.imprimirVelocidad(); 

        auto2.acelerar(20);
        auto2.acelerar(15, true);
        auto2.frenar(12);
        System.out.println(auto2.obtenerVelocidad());

        //método toString()
        //el método toString() es un método heredado de la clase Object, la clase Object es la 
        //clase padre de todas las clases en Java. Por lo tanto, toString() está presente en
        //todas las clases. Su función es proporcionar una representación del objeto en forma
        //de una cadena (String)
        System.out.println(auto2.toString());
        System.out.println(auto1.toString());

        //creamos un objeto de Auto con el constructor completo
        Auto auto3 = new Auto("Citröen", "Picasso", "Gris", 0);
        System.out.println(auto3); //no es necesario colocar el .toString() para llamarlo
        
        Auto auto4 = new Auto("Chevrolet", "Classic", "Celeste");
        System.out.println(auto4);

        Auto auto5 = new Auto("Taunus", "Rojo");
        System.out.println(auto5);

    }
}
