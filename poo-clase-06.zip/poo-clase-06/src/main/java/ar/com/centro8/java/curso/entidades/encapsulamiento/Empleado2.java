package ar.com.centro8.java.curso.entidades.encapsulamiento;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//Lombok
//es una librería para Java que reduce el código repetitivo al generar automáticamente
//en tiempo de compilación algunas partes de las clases.
@Getter //genera los métodos getters de la clase
@Setter //genera los métodos setters de la clase
//tenemos la posibilidad de no incluir algún atributo en los getters o setters
//si declaro algún comportamiento especial dentro de la clase, ese comportamiento va a ser priorizado
@ToString //genera la sobreescritura del método toString()
@AllArgsConstructor //genera el constructor completo
@NoArgsConstructor //genera el constructor vacío
//@RequiredArgsConstructor //genera un constructor que incluye todos los atributos final
//y/o aquellos marcados con @NonNull
/*
 * @Data
 * sirve para evitar tener que crear la anotación de cada funcionalidad por separado
 * genera automáticamente:
 * getters para todos los campos
 * setters para todos los campos
 * toString() que incluye todos los atributos
 * equals() and hashCode() basados en todos los atributos
 * un constructor requerido que incluye todos los campos finales o aquellos marcados con @NonNull 
 */
public class Empleado2 {
    //atributos
    private int id;
    private String nombre;
    private String apellido;
    private String estadoCivil;
    @Getter(AccessLevel.NONE) //el atributo suledoBasico no tendrá método getter
    @Setter(AccessLevel.NONE) //el atributo sueldoBasico no tendrá método setter
    private double sueldoBasico;

    public Empleado2(int id, String nombre, String apellido, String estadoCivil) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.estadoCivil = estadoCivil;
        this.sueldoBasico = 650000;
    }    
        

}
