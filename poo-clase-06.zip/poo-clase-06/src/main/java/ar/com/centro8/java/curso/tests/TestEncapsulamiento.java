package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.encapsulamiento.Empleado;
import ar.com.centro8.java.curso.entidades.encapsulamiento.Empleado2;

public class TestEncapsulamiento {
    public static void main(String[] args) {
        //creamos un objeto de Empleado
        // Empleado empleado1 = new Empleado(); no existe el constructor vacío
        // empleado1.nombre = "Carlos"; no se puede acceder a miembros privados

        Empleado empleado1 = new Empleado(1, "Gerardo", "Sailens", "Casado", 2000000);
        System.out.println(empleado1);

        // System.out.println(empleado1.apellido); el atributo es privado, no puedo acceder directamente
        System.out.println(empleado1.getApellido());

        // empleado1.nombre = "Gerarda";
        //error, el atributo nombre es privado, no se puede acceder directamente
        empleado1.setNombre("Gerarda");
        System.out.println(empleado1.getNombre());

        //creamos un objeto de Empleado2 que implementa Lombok
        Empleado2 empleado2 = new Empleado2(2, "Cosme", "Fulanito", "Soltero");
        System.out.println(empleado2);

        empleado2.setNombre("Cosma");
        System.out.println(empleado2.getNombre());

        /*
         * Diseñar 3 clases que representen: círculos, triángulos (del tipo rectángulo) y rectángulos
         * Cada clase deberá tener implementados los constructores, getters, setters y toString
         * Casa clase deberá poder informar su perímetro y su superficie
         * Testear los funcionamientos de las clases
         */
 
    }
}
