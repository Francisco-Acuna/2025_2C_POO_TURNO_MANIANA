package ar.org.centro8.java.curso.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
