package ar.org.centro8.java.curso.enums;

//Enum es un tipo especial de clase en Java que define un conjunto fijo de constantes con nombre
//Se utiliza para representar valores limitados y conocidos de antemano (dias de la semana, estados
//de una orden, tipos de usuario, etc.)
public enum Dia {
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES,
    VIERNES
}

/*
 * Un enum es como una lista de opciones fijas. En vez de pasar el texto "LUNES", se usa Dia.LUNES
 * y Java impide poner cualquier otro valor que no exista en esa lista.
 * Cada valor dentro del enum representa una constante, que reflejan una instancia de la clase Enum,
 * en este caso, son objetos de la clase Dia que es un enum.
 * Estos objetos, pueden poseer atributos, para ello debe crearse un constructor privado que le
 * permita asignar el valor como estado. Es privado para que desde fuera no se puedan crear más
 * objetos del enum. Al declarar los objetos dentro del enum, se le pasan los parámetros como
 * valores de sus atributos.
 * Implementan Comparable.
 * No pueden extender otra clase, pero pueden implementar interfaces.
 * Se puede sobreescribir el método toString() si quiere presentar otro texto distinto al name()
 */
