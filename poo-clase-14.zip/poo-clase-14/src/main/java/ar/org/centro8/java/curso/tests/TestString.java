package ar.org.centro8.java.curso.tests;

public class TestString {
    public static void main(String[] args) {
        System.out.println("** Clase String **");

        //podemos crear un objeto de la clase String de varias maneras
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("Hola");
        String texto3 = "hola";

        //métodos para comparar
        //al comparar con el operador == va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "Hola"); //false
        //hay una oportunidad en la que la comparación podría darnos true
        System.out.println(texto3 == "hola"); //true
        //existe un comportamiento especial denominado "intering"
        //lo que sucede es que las cadenas creadas con comillas dobles se almacenan en un pool
        //de cadenas internas para ahorrar memoria, es decir, que de manera interna, ocuparían
        //el mismo espacio en memoria. Por eso se las considera iguales.
        //Comparar contenidos de cadenas con el == no brinda un comportamiento garantizado.

        //Para comparar cadenas de caracteres teniendo en cuenta su contenido, se utilizan
        //.equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //false
        System.out.println(texto2.equalsIgnoreCase("hola")); //true
        //IgnoreCase ignora las minúsculas y mayúsculas

        //pasar una cadena a minúsculas o mayúsculas
        //.toLowerCase() .toUpperCase()
        System.out.println(texto1.toLowerCase());
        System.out.println(texto1.toUpperCase());

        //.contains()
        //devuelve un booleano indicando si contiene la subcadena ingresada como parámetro
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto3.contains("hola")); //true

        //.length()
        //devuelve la longitud del vector, es decir, cuántos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4

        //.isEmpty()
        //indica si la cadena está vacía, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false

        //.isBlank() aparece a partir del JDK 11
        //indica si una cadena está en blanco o si consiste únicamente en espacios en blanco
        //como por ejemplo si solo contiene espacios, tabulaciones y/o saltos de línea
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //falso
        System.out.println(texto4.isBlank()); //true

        //charAt()
        //devuelve el caracter del índice indicado como parámetro
        System.out.println(texto1.charAt(3)); //e
        System.out.println(texto2.charAt(3)); //a

    }
}
