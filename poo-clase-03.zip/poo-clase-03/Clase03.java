import java.util.Scanner;

public class Clase03 {
    public static void main(String[] args) {
        //Estructuras

        //condicionales

        //if
        int numero1 = 100;
        int numero2 = 20;

        if(numero1 > numero2){
            System.out.println("El número1 es mayor que el número2");
        }

        if(numero1 > numero2) System.out.println("El número1 es mayor que el número2");
        //if en línea
        //evitamos el uso de las llaves si solo se ejecutará una única sentencia
        //si se van a ejecutar más de una sentencia, se deben colocar las llaves

        //if-else
        if (numero1 > numero2) {
            System.out.println("El número1 es mayor que el número2");
        } else {
            System.out.println("El número1 no es mayor que el número2");
        }

        if(numero1 > numero2) System.out.println("El número es mayor que el número2");
        else System.out.println("El número1 no es mayor que el número2");


        //if-else en cascada (if-else if-else)
        if (numero1 > numero2) {
            System.out.println("El número1 es mayor que el número2");
        } else if (numero1 < numero2){
            System.out.println("El número1 es menor que el número2");
        } else {
            System.out.println("Ambos números son iguales");
        }

        //if-else anidado
        int edad = 22;
        boolean tienePasaporte = true;

        if (tienePasaporte) {
            if (edad >= 18) {
                System.out.println("Puede viajar solo.");
            } else {
                System.out.println("Debe viajar acompañado por un mayor.");
            }
        } else {
            System.out.println("No puede viajar.");
        }

        //operador ternario (if-else abreviado)
        //condición ? valorSiEsVerdadero : valorSiEsFalso

        String mensaje = (edad >= 18) ? "Es mayor de edad" : "Es menor de edad";
        System.out.println(mensaje);

        //estructura switch case
        int dia = 5;

        switch(dia){
            case 1: System.out.println("Lunes"); break;
            case 2: System.out.println("Martes"); break;
            case 3: System.out.println("Miércoles"); break;
            case 4: System.out.println("Jueves"); break;
            case 5: System.out.println("Viernes"); break;
            case 6: System.out.println("Sábado"); break;
            case 7: System.out.println("Domingo"); break;
            default: System.out.println("El día ingresado no es válido");
        }
        //en los switch tradicionales no es obligatorio el uso del default

        switch(dia){
            case 1,2,3,4,5: System.out.println("Es día de semana"); break;
            case 6,7: System.out.println("Es fin de semana"); break;
            default: System.out.println("El día ingresado no es válido");
        }

        //rule switch (JDK 14)
        //se reemplazan los : por las flechas ->
        //desaparecen los break
        //se puede utilizar como una estructura de expresión
        String diaDeSemana = switch(dia){
            case 1 -> "Lunes";
            case 2 -> "Martes";
            case 3 -> "Miércoles";
            case 4 -> "Jueves";
            case 5 -> "Viernes";
            case 6 -> "Sábado";
            case 7 -> "Domingo";
            default -> "Día no válido";
        };
        System.out.println(diaDeSemana);

        //Estructuras repetitivas
        
        //while
        int contador = 1;
        while (contador <= 10){
            System.out.println(contador);
            contador++;
        }

        //do-while con break y continue
        int numero = 0;
        int suma = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println("Se sumarán los números enteros, pares, positivos.");
        System.out.println("Siempre y cuando la suma no supere los 100");
        do{
            System.out.println("Ingrese un número para sumar o el 0 para salir:");
            numero = teclado.nextInt();
            if(numero %2 !=0) continue;
            if(numero > 0) suma += numero;
            if(suma > 100) break;
        } while(numero != 0);

        System.out.println("La suma de los números enteros pares positivos es de: " + suma);

        //for

        for(int i=1; i<=10; i++){
            System.out.println(i);
        }


    }
}
