package ar.org.centro8.java.curso.entidades.varargs;

import lombok.AllArgsConstructor;
import lombok.ToString;

@ToString
@AllArgsConstructor
public class Factura {
    private int numero;
}
