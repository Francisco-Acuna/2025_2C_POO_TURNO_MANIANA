package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import ar.org.centro8.java.curso.entidades.arreglos.Auto;

public class TestCollection {
    public static void main(String[] args) {
        System.out.println("** Interface List **");

        /*
         * La interface List representa una lista con índices, que emula a un Array.
         * List es la única que tiene métodos definidos con índices.
         * De esta interfaz se pueden elegir distintas implementaciones con distintas tecnologías.
         * ArrayList es una lista tipo vector que tiene por dentro un comportamiento similar a
         * un Array, pero que no es un Array, ya que es completamente dinámico.
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente es una lista
         * enlazada.
         * La clase Vector también implementa List, no son los vectores que hemos visto anteriormente.
         * No se recomienda su uso, es una tecnología antigua. Tiene una sincronización excesiva, lo 
         * que la hace demasiado lenta.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una mínima diferencia entre las dos y tiene que ver con la perfomance:
         * ArrayList es más veloz para recorrer elementos.
         * LinkedList es más veloz para agregar y eliminar elementos. 
         */

         //creo una referencia a la interfaz

        List lista;

        lista = new ArrayList<>();

        // .add() método para agregar elementos a un List
        lista.add(new Auto("Peugeot", "308", "Negro"));
        lista.add(new Auto("Chevrolet", "Corsa", "Rojo"));
        //esta lista no tiene especificado un tipo de dato en particular
        //en ese caso queda definida como una lista de la clase Object, por lo tanto, dentro
        //puedo guardar cualquier elemento.
        lista.add("Hola");
        lista.add(83);
        lista.add(23.45);

        System.out.println();

        //recorrido por índices
        System.out.println("-- recorrido por índices de un ArrayList --");
        for (int i = 0; i < lista.size(); i++) { //el método size indica la longitud de la lista
            System.out.println(lista.get(i));
            //con el método .get() obtengo el valor de la posición de índice que pase como parámetro
        }

        // eliminar un elemento
        lista.remove(3); //elimina el elemento del índice 3

        System.out.println("-- recorrido con for-each --");
        for(Object o:lista){
            System.out.println(o);
        }

        System.out.println();

        /*
         * Interface Iterable
         * Iterable es el padre de todas las interfaces del framework Collections.
         * Dentro de Iterable se ecuentra definido el método foreach(), es un método default.
         * Este método realiza un recorrido sobre la lista. No realizamos nosotros una estructura
         * repetitiva, si no que es la misma lista la que se autorecorre.
         * Apareció a apartir del JDK 8.
         * El método foreach() estará presente para todas las colecciones. 
         */

        System.out.println("-- recorrido con método foreach() --");
        lista.forEach(item -> System.out.println(item));
        //el foreach() recibe como parámetro una Lambda Expression
        //en este caso, item representa a cada elemento de la lista, luego con el operador flecha
        //le indico que para ese parámetro (el elemento de la lista) realiza la o las acciones que
        //siguen. En este caso, la acción es imprimir por consola el mismo elemento que se recibió
        //como parámetro.

        //si quisiéramos definir más de una sentencia tenemos que abrir llaves
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println(" - ");
        });

        System.out.println();

        //Referencia de métodos (Method references)
        System.out.println("-- recorrido con foreach() simplificado --");
        lista.forEach(System.out::println);
        //si solo vamos a escribir una única sentencia, podemos omitir el uso del párametro y la flecha
        //con el operador de :: le estamos indicando a Java que el ítem implícito lo coloque como
        //argumento del método.
        //Esta es una sintaxis moderna, cómoda, prolija y abreviada.

        System.out.println("\n** ListIterator **");
        /*
         * ListIterator es una interfaz especializada para recorrer colecciones que implementan List.
         * A diferencia del iterador simple (Iterator) o del método foreach() de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         * - recorrido bidireccional: permite avanzar y retroceder sobre las listas
         * - tiene acceso a índices
         * - permite eliminar, reemplazar y agregar elementos durante la iteración.
         */

        List nombres = new ArrayList<>();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcelo");

        //obtener el ListIterator de la lista
        ListIterator<String> li = nombres.listIterator();

        //recorrido hacia adelante
        System.out.println("\n-- recorrido hacia adelante --");
        while(li.hasNext()){ //comprueba si queda al menos un elemento más por recorrer en adelante
            int indice = li.nextIndex(); //nexIndex() devuelve el índice del elemento que se devolverá
            String nombre = li.next(); //next() devuelve el siguiente elemento
            System.out.println("Índice " + indice + ": " + nombre);
        }

         
    }
}
