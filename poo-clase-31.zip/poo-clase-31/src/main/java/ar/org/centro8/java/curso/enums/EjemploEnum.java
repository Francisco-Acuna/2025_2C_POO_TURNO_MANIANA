package ar.org.centro8.java.curso.enums;

public enum EjemploEnum {
    //representamos estados de un pedido
    PENDIENTE("pendiente de envío"),
    EN_PROCESO("en proceso de preparación"),
    ENTREGADO("entregado al cliente");

    private final String descripcion;

    private EjemploEnum(String descripcion){
        this.descripcion = descripcion;
    }

    @Override
    public String toString(){
        return name() + " -> " + descripcion;
    }
}
