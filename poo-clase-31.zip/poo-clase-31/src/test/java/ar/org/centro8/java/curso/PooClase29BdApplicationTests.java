package ar.org.centro8.java.curso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooClase29BdApplicationTests {

	@Test
	void contextLoads() {
	}

}
