package ar.org.centro8.java.curso.tests;

public class TestExceptions {
    public static void main(String[] args) {
        //si ejecutamos el siguiente código se va a generar un error
        // System.out.println(10/0);
        // System.out.println("Esta sentencia no se ejecuta");
        //Este error va a detener la JVM dando una devolución de 1, lo que signfica que el 
        //programa finalizó con errores.
        //El programa se detiene de forma incorrecta.

        //Manejo de excepciones
        //Estructura try-catch-finally -> mecanismo para el manejo de excepciones
        try { //obligatorio
            /*
             * En este bloque se colocan todas las sentencias que puedan lanzar una excepción.
             * Si no se produce ningún error el bloque se ejecuta normalmente y salta al bloque
             * finally (si es que existe).
             * Si se lanza una excepción, la ejecución del bloque try se detiene inmediatamente
             * y se transfiere el control al bloque catch
             */
        } catch (Exception e) { //obligatorio (la mayoría de las veces)
            /*
             * En este bloque se definen las acciones a realizar cuando se produce una Exception.
             * Se captura la excepción mediante un objeto del tipo Exception que contiene información
             * del error.
             * El programa continúa su ejecución después de este bloque, sin detenerse abruptamente.
             * Salta al bloque finally si es que existe.
             */
        } finally { //opcional
            /*
             * Este bloque se ejecuta siempre, independientemente de que se haya lanzado o no una
             * excepción.
             * Se utiliza para liberar recursos o realizar tareas de limpieza. Como cerrar archivos,
             * conexiones a bases de datos, etc.
             * Las variables declaradas dentro de los bloques try o catch no son accesibles desde
             * este bloque, ya que el alcance (scope) es local a esos bloques.
             */
        }

        //ejemplo
        try {
            System.out.println(10/0);
            //el error no detiene el programa
            System.out.println("Esta sentencia no se ejecuta si salta una exepción");
        } catch (Exception e) {
            System.out.println("Mensaje del bloque catch: Ocurrió un error");
            // System.out.println(e); //imprimo el objeto del error.
            // System.out.println(e.getMessage()); //mensaje corto con la descripción
            // System.out.println(e.getLocalizedMessage()); //similar a getMessage() pero devuelve
            //un mensaje traducido según la configuración regional si es que fue sobreescrita
            // System.out.println(e.getCause()); //retorna la causa (otra Exception) que provocó la 
            //excepción actual
            e.printStackTrace(); //imprime la traza completa de la pila. Lo que facilita la depuración
            //al mostrar la secuencia de llamadas que condujeron a la excepción.
        } finally {
            System.out.println("Mensaje del boque finally: Este bloque se ejecuta siempre");
        }

        System.out.println("Mensaje fuera del bloque try-catch-finally: Esta sentencia se "+
        "ejecuta sin problemas, haya habido o no una excepción.");

        System.out.println("El programa finaliza normalmente.");

        /*
         * La clase raíz de las excepciones es Throwable que extiende de Object. Esta clase
         * representa todo lo que puede "lanzarse" (throw) y que puede interrumpir el flujo
         * normal del programa.
         * 
         * Throwable tiene dos clases principales: Error y Exception.
         * 
         * Error: 
         *  - representa errores graves, generalmente relacionados con la JVM o fallos críticos
         * del hardware (por ejemplo, OutOfMemory, StackOverFlowError, etc.).
         *  - estos errores no están diseñados para ser capturados ni manejados, ya que indican
         * consiciones de las que lz aplicación en la mayoría de los casos no puede recuperarse.
         *  - dentro de Error se encuentra AssertionError que se lanza cuando falla una aserción
         * (assert). Las aserciones se utilizan principalmente para pruebas y diagnóstico, y se 
         * pueden habilitar o deshabilitar en tiempo de ejecución, mediante las opciones -ea 
         * (enable assertions) y -da (disable assertions).
         *  
         * Exception:
         *  - representa condiciones anómalas que pueden ocurrir durante la ejecución del programa
         * y que, en muchos casos, pueden ser manejadas o recuperadas.
         *  - dentro de Exception existen dos tipos:
         *      - **Checked exceptions**: son aquellas que el compilador obliga a capturar o declarar
         * en la firma de los métodos (por ejemplo IOException, SQLException, etc.). Estas excepciones
         * heredan directamente de Exception.
         *      -**Unchecked exceptions**: son aquellas que no es obligatorio capturar o declarar, ya
         * que generalmente indican errores de lógica o condiciones inesperadas (por ejemplo NullPointerException,
         * ArithmeticException, ArrayIndexOutOfBoundsException, etc.). Estas sentencias extienden de 
         * RuntimeException.
         * 
         * throwable -> raíz de todos los objetos "lanzables" en Java
         * Error -> errores graves que no deben o no se pueden manejar.
         * Exception -> condiciones de error que se pueden manejar, divididas en:
         *  Checked exceptions -> obligatorias de capturar o declarar.
         *  Unchecked exceptions -> no son obligatorias de capturar.
         */


    }
}
