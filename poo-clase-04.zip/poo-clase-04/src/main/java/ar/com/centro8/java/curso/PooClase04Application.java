package ar.com.centro8.java.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooClase04Application {

	public static void main(String[] args) {
		SpringApplication.run(PooClase04Application.class, args);
	}

}
