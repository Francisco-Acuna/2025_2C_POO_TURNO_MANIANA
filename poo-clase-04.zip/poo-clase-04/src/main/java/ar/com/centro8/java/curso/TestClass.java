package ar.com.centro8.java.curso;

public class TestClass {
    public static void main(String[] args) {
        System.out.println("** Test de la clase Auto **");

        //construimos un objeto de la clase Auto
        Auto auto1 = new Auto();
        //un objeto es una instancia de una clase, es decir, una entidad con
        //características (atributos) y comportamiento (métodos)

        //damos estado al objeto (completar el valor de sus atributos)
        auto1.marca = "Fiat";
        auto1.modelo = "Fiorino";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        //imprimimos los valores de los atributos
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

        //utilizamos los métodos de la clase Auto
        auto1.acelerar();
        System.out.println(auto1.velocidad);

        auto1.acelerar();
        auto1.acelerar();
        auto1.acelerar();
        System.out.println(auto1.velocidad);


    }
}
