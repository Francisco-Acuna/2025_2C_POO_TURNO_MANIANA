package ar.org.centro8.java.curso.entidades.keywords;

public class Auto {
    //cuando un atributo es declarado como final, queda cosntante
    //es decir, que no se modifica su valor.
    //La keyword final a nivel atributo o variable determina que es una constante.
    // private final String marca;
    // private final String modelo;
    // private final String color;
    // private final int velocidad;



}
