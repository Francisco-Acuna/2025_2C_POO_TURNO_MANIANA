package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.java.curso.entidades.arreglos.Auto;

public class TestCollection {
    public static void main(String[] args) {
        System.out.println("** Interface List **");

        /*
         * La interface List representa una lista con índices, que emula a un Array.
         * List es la única que tiene métodos definidos con índices.
         * De esta interfaz se pueden elegir distintas implementaciones con distintas tecnologías.
         * ArrayList es una lista tipo vector que tiene por dentro un comportamiento similar a
         * un Array, pero que no es un Array, ya que es completamente dinámico.
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente es una lista
         * enlazada.
         * La clase Vector también implementa List, no son los vectores que hemos visto anteriormente.
         * No se recomienda su uso, es una tecnología antigua. Tiene una sincronización excesiva, lo 
         * que la hace demasiado lenta.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una mínima diferencia entre las dos y tiene que ver con la perfomance:
         * ArrayList es más veloz para recorrer elementos.
         * LinkedList es más veloz para agregar y eliminar elementos. 
         */

         //creo una referencia a la interfaz

         List lista;

         lista = new ArrayList<>();

         // .add() método para agregar elementos a un List
         lista.add(new Auto("Peugeot", "308", "Negro"));
         lista.add(new Auto("Chevrolet", "Corsa", "Rojo"));
         
    }
}
