package ar.org.centro8.java.curso.tests;

public class TestArrays {
    public static void main(String[] args) {
        
    }
}
