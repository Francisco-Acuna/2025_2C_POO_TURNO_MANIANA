package ar.org.centro8.java.curso.entidades.arreglos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class Auto {
    private String marca;
    private String modelo;
    private String color;
}
