package ar.org.centro8.java.curso.tests;

import java.util.Scanner;

public class TestString {
    public static void main(String[] args) {
        System.out.println("** Clase String **");

        //podemos crear un objeto de la clase String de varias maneras
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("Hola");
        String texto3 = "hola";

        //métodos para comparar
        //al comparar con el operador == va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "Hola"); //false
        //hay una oportunidad en la que la comparación podría darnos true
        System.out.println(texto3 == "hola"); //true
        //existe un comportamiento especial denominado "intering"
        //lo que sucede es que las cadenas creadas con comillas dobles se almacenan en un pool
        //de cadenas internas para ahorrar memoria, es decir, que de manera interna, ocuparían
        //el mismo espacio en memoria. Por eso se las considera iguales.
        //Comparar contenidos de cadenas con el == no brinda un comportamiento garantizado.

        //Para comparar cadenas de caracteres teniendo en cuenta su contenido, se utilizan
        //.equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //false
        System.out.println(texto2.equalsIgnoreCase("hola")); //true
        //IgnoreCase ignora las minúsculas y mayúsculas

        //pasar una cadena a minúsculas o mayúsculas
        //.toLowerCase() .toUpperCase()
        System.out.println(texto1.toLowerCase());
        System.out.println(texto1.toUpperCase());

        //.contains()
        //devuelve un booleano indicando si contiene la subcadena ingresada como parámetro
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto3.contains("hola")); //true

        //.length()
        //devuelve la longitud del vector, es decir, cuántos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4

        //.isEmpty()
        //indica si la cadena está vacía, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false

        //.isBlank() aparece a partir del JDK 11
        //indica si una cadena está en blanco o si consiste únicamente en espacios en blanco
        //como por ejemplo si solo contiene espacios, tabulaciones y/o saltos de línea
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //falso
        System.out.println(texto4.isBlank()); //true

        //charAt()
        //devuelve el caracter del índice indicado como parámetro
        System.out.println(texto1.charAt(3)); //e
        System.out.println(texto2.charAt(3)); //a

        //.indexOf()
        //devuelve el índice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); //no la encuentra porque lleva T mayúscula -1
        System.out.println(texto1.indexOf("Texto")); //10

        //.trim()
        //quita los espacios de adelante y atrás
        System.out.println("   Buenas noches   ");
        System.out.println("   Buenas noches   ".trim());

        //.startsWith() .endsWith()
        //devuelve un booleano que indica si la cadena comienza o termina con un texto determinado
        System.out.println(texto1.startsWith("hola")); //false
        System.out.println(texto2.startsWith("Hola")); //true
        System.out.println(texto1.endsWith("exto")); //false
        System.out.println(texto1.endsWith("exto!")); //true

        //.substring()
        //extrae una subcadena desde la posición que le indiquemos como parámetro
        System.out.println(texto1.substring(10)); //Texto!
        //con dos parámetros, indicamos la posición de inicio y la posición de final de la subcadena
        //la posición final, no se incluye en la devolución
        System.out.println(texto1.substring(0, 6)); //Cadena

        //métodos replace
        //reemplazar un caracter por otro
        System.out.println(texto1.replace('e', 'i')); //Cadina di Tixto!
        //reemplaza una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres")); //Cadena de caracteres!
        System.out.println(texto1);
        texto3 = "manzana, manzana, naranja";
        //reemplazar solo la primera vez que aparezca la cadena
        System.out.println(texto3.replaceFirst("manzana", "banana")); //banana, manzana, naranja
        //reemplazar todas las veces que aparezca la cadena
        System.out.println(texto3.replaceAll("manzana", "banana")); //banana, banana, naranja
        System.out.println(texto3.replace("manzana", "banana")); //banana, banana, naranja
        //si bien replace() y replaceAll() reemplazan todas las apariciones,
        //replaceAll() es mucho más potente. Permite buscar y reemplazar patrones de expresiones
        //regulares. Se conocen como regex regexp. Una expresión regular es una secuencia de 
        //caracteres que definen un patrón, en este caso es un patrón de búsqueda. Los patrones
        //indican qué reglas deben serguir las distintas instrucciones.
        String texto5 = "Mi número de teléfono es 011-8888-9999 y mi número laboral es 011-5555-4444";
        System.out.println(texto5.replaceAll("\\d{3}-\\d{4}-\\d{4}", "#########"));

        //repeat()
        //repite la cadena la cantidad de veces que se indique como parámetro
        System.out.println(texto2.repeat(3)); //HolaHolaHola

        //caracteres de escape
        //son secuencias especiales de caracteres que se utilizan en cadenas de texto y literales
        //de caracteres para representar caracteres especiales que no se pueden representar directamente
        //Los caracteres de escape comienzan con una barra invertida (\) seguida de un caracter que
        //indica qué tipo de escape se está utilizando.
        //algunos ejemplos:

        // \n salto de línea
        System.out.println("Hola\nMundo!");
        
        // \t tabulación
        System.out.println("Hola\tMundo!");

        // \" comillas dobles
        System.out.println("\"Hola Mundo!\"");

        // \\ barra invertida
        System.out.println("\\Hola Mundo!\\");

        //pedirle al usuario que ingrese su nombre completo (solo primer nombre y solo primer apellido)
        //mostrar luego, primero el apellido y luego el nombre, con la primera letra en mayúscula
        //y el resto en minúscula
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Hey chavón, poné tu nombre y apellido, solo un nombre y solo un apellido:");
        String nombreCompleto = teclado.nextLine();
        int espacio = nombreCompleto.indexOf(" ");
        String nombre = nombreCompleto.substring(0, espacio);
        String apellido = nombreCompleto.substring(espacio+1);
        System.out.println(nombre.toUpperCase().charAt(0) + nombre.substring(1) );
        System.out.println(apellido.toUpperCase().charAt(0) + apellido.substring(1) );



    }
}
