package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.ClientePersona;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestObjetos {
    public static void main(String[] args) {
        
        /*
        * En Java existe la clase Class, y Java, internamente, toma a todas las clases que nosotros
        * creamos como objetos de la clase Class, en tiempo de ejecución.
        * Los atributos son tratados en Java como objetos de la clase Field, que se encuentra en el
        * paquete java.lang.reflect.Field
        * Los métodos son tratados internamente como objetos de la clase Method que se encuentra en
        * el paquete java.lang.reflect.Method
        * Esta es la base del API de reflexión de Java, la cual nos permite inspeccionar y manipular
        * información de clases, métodos y atributos en tiempo de ejecución.
        * Aunque nosotros no creemos los objetos de Field o Method directamente, el compilador y la
        * JVM generan estos objetos internamente para gestionar la información de nuestras clases.
        * Las clases públicas de java.lang son accesibles de manera global.
        */

        Direccion direccion1 = new Direccion("Av. Medrano", 162, "2", "8");
        Cuenta cuenta1 = new Cuenta(1, "Pesos argentinos");
        Persona persona1 = new Empleado("Saul", "Hudson", 51, direccion1, 65, 1_500_000);
        //el guión bajo es estético, no modifica el comportamiento, solo sirve para 
        //separar visualmente las unidades 
        System.out.println(persona1);
        Persona persona2 = new ClientePersona("Franco", "Colapinto", 22, direccion1, 10, cuenta1);

        //si queremos guardar persona1 dentro de un objeto de Empleado, tenemos un error
        //ya que persona1 está guardada dentro de un contenedor mayor, que es del tipo Persona
        // Empleado empleado1 = persona1;
        //para resolver esta situación, tenemos que castear la asignación
        //castear significa convertir una variable de un tipo a otro
        //es una forma de indicarle al compilador que trate a un objeto o valor como si fuera de otro tipo
        Empleado empleado1 = (Empleado) persona1;
        //si pasáramos otro tipo de dato, Java lo va a intentar asignar igual, pero va a arrojar una
        //java.lang.ClassCastException y detendrá el programa.



    }
}
